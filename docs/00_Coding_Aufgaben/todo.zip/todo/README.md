# Todo
Meine Projektidee ist es eine Todo Liste zu erstellen.

## Klassen
Es soll vier Klassen geben:
  - Benutzer (Vorname, Nachname, E-Mail, Passwort, ToDoListen)
  - SharedToDoList (Name, Beschreibung, Aufgaben, evt. Benutzer)
  - Aufgaben (Name, Beschreibung, Priorität, Status, Bild)
  - Bilder (Beschreibung, Pfad, Format)

Machen:

- Klassendiagramm
- Sequenzdiagramm
- Aktivitätsdiagramm